#INSTALL FUNC 将MODS目录下所有后缀为.zip的文件视作模块安装
#$1:mod's name
INSTALL(){
magisk --install-module $1 >/dev/mod_log.log 2>&1
cat /dev/mod_log.log | while read line
do
    ui_print "${line}"
done
}

for i in $(find $MODPATH/MODSbeforeReboot/ -name "*.zip" -mindepth 1 -maxdepth 1); do
INSTALL $i
done
echo
echo
echo 如果出现有影响的root环境异常，还需在/data/adb/tricky_store/target.txt添加异常应用包名（若无效还可试试在前添加!）
echo
echo
echo
echo
echo
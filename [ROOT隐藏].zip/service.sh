MODDIR=${0%/*}

for i in $(find $MODDIR/MODSafterReboot/ -name "*.zip" -mindepth 1 -maxdepth 1); do
INSTALL $i
done

rm -rf $MODDIR